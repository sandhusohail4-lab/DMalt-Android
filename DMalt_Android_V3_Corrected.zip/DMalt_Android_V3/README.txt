D.Malt Android V3

This is the corrected project package for building the D.Malt Android app.
It includes a GitHub Actions workflow at .github/workflows/build-apk.yml.

Phone build route:
1. Extract this ZIP.
2. Upload ALL files/folders to a GitHub repository, including the hidden .github folder.
3. Open GitHub > Actions.
4. Select "Build D.Malt APK".
5. Run the workflow.
6. Download the "DMalt-debug-apk" artifact.
7. Extract it and install app-debug.apk on Android.

No map and no product prices are included in this starter project.
